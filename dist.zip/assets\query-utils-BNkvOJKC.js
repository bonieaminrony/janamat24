function i(e,r=1e4){return Promise.race([e,new Promise((t,o)=>setTimeout(()=>o(new Error("সার্ভার রেসপন্স করছে না (Timeout)")),r))])}export{i as w};
